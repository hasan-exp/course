from odoo import models, fields

class HospitalPaitent(models.Model):
    _name = "hospital.paitent"

    name = fields.Char("Paitent Name")
    phone = fields.Char("Phone")

