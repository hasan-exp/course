{
    'name' : "Hospital System",
    "summary" : "Testing Odoo Tehnical",
    "author" : "Expert Co",
    "discription" : "test odoo with hospital case study",
    "depends" : ["base"],
    "data" : [
        "views/hospital_view.xml"
    ],
    "application" : True
}